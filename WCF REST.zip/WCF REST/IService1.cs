﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Data;

namespace WCF_REST
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IService1
    {

        [OperationContract]
        bool InsertData(Employee1 obj);
        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "/ShowAll/")]
        List<Employee1> ShowAll();
        [OperationContract]
        [WebInvoke(Method = "POST", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "/ShowAll/")]
        List<Employee1> getRecordbyId(int id);
        [OperationContract]
        bool UpdateData(Employee1 obj);
        [OperationContract]
        bool DeleteData(Employee1 obj);


    }
        [DataContract]
        public class Employee
        {

            string _name = "";
            string _email = "";
            string _phone = "";
            string _gender = "";
            [DataMember]
            public int EmpId
            {
                get { return EmpId; }
                set { EmpId = value; }
            }

            [DataMember]
            public string EmpName
            {
                get { return _name; }
                set { _name = value; }
            }

            [DataMember]
            public string CompanyName
            {
                get { return _email; }
                set { _email = value; }
            }

            [DataMember]
            public string Location
            {
                get { return _phone; }
                set { _phone = value; }
            }

            [DataMember]
            public string Dept
            {
                get { return _gender; }
                set { _gender = value; }
            }
        }
    }

