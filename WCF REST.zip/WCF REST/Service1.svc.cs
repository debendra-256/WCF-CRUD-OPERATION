﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


namespace WCF_REST
{
    public class Service1 : IService1
    {
        WCFDAL myobject = new WCFDAL();
        public bool InsertData(Employee1 obj)
        {
            string query = "insert into Employee(EmpName,CompanyName,Location,Dept) values('" + obj.EmpName + "','" + obj.CompanyName + "','" + obj.Location + "','" + obj.Dept + "')";
            bool x = myobject.DML(query);
            return x;



        }
        public  bool UpdateData(Employee1 obj)
        {
            string query = "update Employee set EmpName='" + obj.EmpName + "',CompanyName='" + obj.CompanyName + "',Location='" + obj.Location + "',Dept='" + obj.Dept + "' where Empid='" + obj.EmpId + "' ";
            bool x = myobject.DML(query);
            return x;


        }
       public bool DeleteData(Employee1 obj)
        {
            string query = "Delete from Employee where Empid='" + obj.EmpId + "'";
            bool x = myobject.DML(query);
            return x;

        }

        public List<Employee1> ShowAll()
        {
            List<Employee1> li = new List<Employee1>();
            string s = "select * from Employee";
            DataTable dt = new DataTable();
            dt = myobject.getdata(s);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                Employee1 emp = new Employee1();
                emp.EmpId = Convert.ToInt32(dt.Rows[i]["EmpId"]);
                emp.EmpName = dt.Rows[i]["EmpName"].ToString();
                emp.CompanyName = dt.Rows[i]["CompanyName"].ToString();
                emp.Dept = dt.Rows[i]["Dept"].ToString();
                emp.Location = dt.Rows[i]["Location"].ToString();
                
               
                li.Add(emp);
               
            }


            return li;

            

        }
        public List<Employee1> getRecordbyId(int id)
        {
            List<Employee1> li = new List<Employee1>();
            DataTable dt1 = new DataTable();
            string query="select * from Employee where EmpId='"+id+"'";
           dt1= myobject.getdata(query);
            if(dt1.Rows.Count>0)
            {
                for (int i = 0; i < dt1.Rows.Count; i++)
                {
                    Employee1 emp = new Employee1();
                    emp.EmpId = Convert.ToInt32(dt1.Rows[i]["EmpId"]);
                    emp.EmpName = dt1.Rows[i]["EmpName"].ToString();
                    emp.CompanyName = dt1.Rows[i]["CompanyName"].ToString();
                    emp.Dept = dt1.Rows[i]["Dept"].ToString();
                    emp.Location = dt1.Rows[i]["Location"].ToString();


                    li.Add(emp);

                }
                return li;

            }
            else
            {
                return li;
            }
         

        }
  
    }
}