﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WCF_REST
{
    public class Employee1
    {
        public int EmpId { get; set; }
        public string EmpName { get; set; }
        public string CompanyName { get; set; }
        public string Location { get; set; }
        public string Dept { get; set; }
     
    }
}