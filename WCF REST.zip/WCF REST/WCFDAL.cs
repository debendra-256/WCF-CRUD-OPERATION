﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace WCF_REST
{
    public class WCFDAL
    {
        SqlCommand cmd;
        SqlDataAdapter da;
        DataSet ds;
        public static SqlConnection connection()
        {
            string s = ConfigurationManager.ConnectionStrings["connect"].ConnectionString;
            SqlConnection con = new SqlConnection(s);
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            else
            {
                con.Open();
            }
            return con;
        }
        public bool DML(string Query)
        {
            cmd = new SqlCommand(Query, WCFDAL.connection());
            int x = cmd.ExecuteNonQuery();
            if(x==1)
            {
                return true;
            }
            else
            {
                return false;
            }



        }
        public DataTable getdata(string query)
        {
            da = new SqlDataAdapter(query, WCFDAL.connection());
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
            

        }
       

    }
}